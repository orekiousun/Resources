﻿using UnityEngine;

public class XLuaMemoryGUI : MonoBehaviour
{
    [Range(0, 1)] public float deltaMemoryRateX = 0.01f;
    [Range(0, 1)] public float deltaMemoryRateY = 0.6f;
    [Range(0, 1)] public float totalMemoryRateX = 0.01f;
    [Range(0, 1)] public float totalMemoryRateY = 0.64f;

    private GUIStyle guiStyle;
    private GUIStyle guiStyleGreen;
    private GUIStyle guiStyleRed;

    [Space] public int deltaMemoryGreenVal = 1000;
    public int deltaMemoryRedVal = 1000;

    private int deltaMemory;
    private int lastTotalMemory;
    private int frameAccumulate;
    public int deltaMemorySyncFrame = 60;

    private void OnGUI()
    {
        if (XLuaStart.m_luaEnv != null)
        {
            InitGUIStyle();

            int totalMemory = XLuaStart.m_luaEnv.Memroy;

            if (frameAccumulate++ > deltaMemorySyncFrame)
            {
                frameAccumulate = 0;
                deltaMemory = totalMemory - lastTotalMemory;
                lastTotalMemory = totalMemory;
            }

            int width = Screen.width;
            int height = Screen.height;
            GUI.Label(new Rect(width * deltaMemoryRateX, height * deltaMemoryRateY, 500, 500),
                new GUIContent($"DeltaMem:  {(deltaMemory >= 0 ? "+" : "")}{deltaMemory.ToString()} KB"),
                deltaMemory > 0 ? (deltaMemory > deltaMemoryRedVal ? guiStyleRed : guiStyle) : (deltaMemory < -deltaMemoryGreenVal ? guiStyleGreen : guiStyle));
            GUI.Label(new Rect(width * totalMemoryRateX, height * totalMemoryRateY, 500, 500),
                new GUIContent($"TotalMem:  {totalMemory.ToString()} KB"), guiStyle);
        }
    }

    private void InitGUIStyle()
    {
        if (guiStyle == null || guiStyleGreen == null || guiStyleRed == null)
        {
            guiStyle = new GUIStyle(GUI.skin.label);
            guiStyle.fontSize = 20;
            guiStyle.normal.textColor = new Color(0, 1, 1, 1);

            guiStyleGreen = new GUIStyle(guiStyle);
            guiStyleGreen.normal.textColor = new Color(0, 1, 0, 1);
            guiStyleRed = new GUIStyle(guiStyle);
            guiStyleRed.normal.textColor = new Color(1, 0, 0, 1);
        }
    }

    private void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }
}