﻿using UnityEngine;

using System;

//[CreateAssetMenu(menuName = "CustomHiererchyConfig", fileName = "CustomHiererchyConfig")]
public class CustomHierarchyConfig : ScriptableObject
{
    /// <summary>
    /// 图标Rect大小(图标尺寸再-2)
    /// </summary>
    [Space()]
    public int iconRectSize = 18;

    /// <summary>
    /// 第一个(最右侧)图标离右侧距离
    /// </summary>
    [Space()]
    public int firstSpacing = 20;

    /// <summary>
    /// 图标之间间距
    /// </summary>
    [Space()]
    public int iconSpacing = 26;

    /// <summary>
    /// insID距离右侧距离
    /// </summary>
    [Space()]
    public float insIDRightMargin = 200;

    /// <summary>
    /// 图标最小显示宽度
    /// </summary>
    [Space()]
    public float minIconShowWidth = 150;

    /// <summary>
    /// 最小显示宽度
    /// </summary>
    [Space()]
    public float minShowWidth = 130;

    /// <summary>
    /// 字体颜色偏移X
    /// </summary>
    [Space()]
    public float fontColorOffsetX = 18f;

    /// <summary>
    /// 字体颜色偏移Y
    /// </summary>
    [Space()]
    public float fontColorOffsetY = .0f;

    /// <summary>
    /// 区块颜色模型
    /// </summary>
    [Header("区块颜色")]
    public AreaColorModel[] models;

    /// <summary>
    /// 组件颜色高亮模型
    /// </summary>
    [Header("组件图标及颜色高亮")]
    public HighlightColorModel[] highlightModels;

    /// <summary>
    /// 区域颜色模型
    /// </summary>
    [Serializable]
    public class AreaColorModel
    {
        public string target;
        public Color color;

        public AreaColorModel()
        {
            color = Color.white;
        }
    }

    /// <summary>
    /// 组件颜色高亮模型
    /// </summary>
    [Serializable]
    public struct HighlightColorModel
    {
        public string assemblyName;
        public HighlightColorItem[] items;
    }

    [Serializable]
    public class HighlightColorItem
    {
        public string componentName;
        public Color color;

        public HighlightColorItem()
        {
            color = Color.white;
        }
    }
}
