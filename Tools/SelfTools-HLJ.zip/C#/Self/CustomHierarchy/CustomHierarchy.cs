﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using System.Collections;
using System.Reflection;
using System.Diagnostics;

using UnityEngine;
using UnityEditor;
using UnityEngine.EventSystems;
using UnityEngine.AI;
using UnityEngine.Video;
using UnityEngine.UI;
using UnityEngine.Playables;
using TMPro;

using Debug = UnityEngine.Debug;

[InitializeOnLoad]
public class CustomHierarchy
{
    private static GUIStyle iconStyle;
    private static GUIStyle colorLabelStyle;
    private static GUIStyle insIDStyle;

    private static CustomHierarchyConfig customConfig;
    //配置文件路径
    private const string CustomConfigPath = @"Assets/Script/Self/CustomHierarchy/CustomHierarchyConfig.asset";

    //InsID距离右边的距离
    private static float insIDRightMargin = 200;
    //图标Rect大小(图标尺寸再-2)
    private static int iconRectSize = 18;
    //第一个(最右侧)图标离右侧间距
    private static int firstSpacing = 20;
    //图标之间间距
    private static int iconSpacing = 26;
    //图标最小显示宽度
    private static float minIconShowWidth = 170;
    //最小显示宽度
    private static float minShowWidth = 120;

    //颜色字体偏移
    private static float colorFontOffsetX = 18f;
    private static float colorFontOffsetY = 0f;

    //原始背景颜色
    private static Color baseColor;

    //hierarchy视图发生改变
    private static bool hierarchyChanged = true;

    //自定义组件颜色高亮列表
    private static List<IconInfoModel> iconInfoList = new List<IconInfoModel>();
    //区块颜色
    private static Dictionary<string, Color> areaColorDic = new Dictionary<string, Color>();
    //子物体颜色表
    private static Dictionary<int, Color> subColorDic = new Dictionary<int, Color>();

    static CustomHierarchy()
    {
        EditorApplication.hierarchyWindowItemOnGUI += HierarchyWindowOnGUI;
        EditorApplication.hierarchyChanged += HierarchyChanged;

        colorLabelStyle = new GUIStyle();
        insIDStyle = new GUIStyle();

        iconStyle = new GUIStyle();
        iconStyle.fixedWidth = iconRectSize - 2;
        iconStyle.fixedHeight = iconRectSize - 2;

        baseColor = GUI.backgroundColor;

        //读取配置
        customConfig = (CustomHierarchyConfig)AssetDatabase.LoadAssetAtPath<ScriptableObject>(CustomConfigPath);
        if (customConfig == null) Debug.LogError("CustomHierarchy无法获取配置文件，请检查CustomHierarchy.CustomConfigPath");
        InitData();
        UpdateAreaColorList();
    }

    ~CustomHierarchy()
    {
        EditorApplication.hierarchyWindowItemOnGUI -= HierarchyWindowOnGUI;
        EditorApplication.hierarchyChanged -= HierarchyChanged;

        GUI.backgroundColor = baseColor;
    }

    //根据index排序获取对应Rect
    private static Rect CreateRect(Rect selectionRect, ref int index)
    {
        Rect rect = new Rect(selectionRect);
        rect.x += rect.width - firstSpacing - (iconSpacing * index);
        rect.width = iconRectSize;
        index++;
        return rect;
    }

    //根据类型绘制图标
    private static void DrawComponentIcon(Rect rect, Type type, GUIStyle customStyle = null)
    {
        //获得Unity内置的图标
        Texture icon = EditorGUIUtility.ObjectContent(null, type).image;
        if (icon == null)
        {
            return;
        }
        if (customStyle != null)
        {
            GUI.Label(rect, icon, customStyle);
        }
        else
        {
            Color origin = GUI.color;
            GUI.color = GUI.backgroundColor;
            GUI.Label(rect, icon, iconStyle);
            GUI.color = origin;
        }
    }

    //根据类型绘制对应图标和颜色
    private static bool Draw(Type type, Rect selectionRect, GameObject go, ref int order)
    {
        if (!HasComponent(go, type, false))
        {
            return false;
        }
        Rect rect = CreateRect(selectionRect, ref order);
        DrawComponentIcon(rect, type);
        return true;
    }

    private static void InitData()
    {
        areaColorDic.Clear();
        if (customConfig != null)
        {
            iconRectSize = customConfig.iconRectSize;
            firstSpacing = customConfig.firstSpacing;
            iconSpacing = customConfig.iconSpacing;
            insIDRightMargin = customConfig.insIDRightMargin;
            minIconShowWidth = customConfig.minIconShowWidth;
            minShowWidth = customConfig.minShowWidth;
            colorFontOffsetX = customConfig.fontColorOffsetX;
            colorFontOffsetY = customConfig.fontColorOffsetY;

            CustomHierarchyConfig.AreaColorModel[] models = customConfig.models;
            for (int i = 0; i < models.Length; i++)
            {
                if (models[i].target != null && !models[i].target.Equals(""))
                {
                    areaColorDic.Add(models[i].target, models[i].color);
                }
            }

            iconInfoList.Clear();
            CustomHierarchyConfig.HighlightColorModel[] hlModels = customConfig.highlightModels;
            for (int i = 0; i < hlModels.Length; i++)
            {
                if (hlModels[i].assemblyName != null && !hlModels[i].assemblyName.Equals(""))
                {
                    Assembly assembly = null;
                    try
                    {
                        assembly = Assembly.Load(hlModels[i].assemblyName);
                    }
                    catch (Exception e)
                    {
                        Debug.LogError(e.StackTrace + "\n" + e.Message);
                        continue;
                    }
                    if (assembly == null)
                    {
                        Debug.LogWarning("未找到程序集: " + hlModels[i].assemblyName);
                        continue;
                    }
                    CustomHierarchyConfig.HighlightColorItem[] hlItems = hlModels[i].items;
                    for (int j = 0; j < hlItems.Length; j++)
                    {
                        if (hlItems[j].componentName != null && !hlItems[j].componentName.Equals(""))
                        {
                            Type type = assembly.GetType(hlModels[i].assemblyName + "." + hlItems[j].componentName);
                            if (type == null && (type = assembly.GetType(hlItems[j].componentName)) == null)
                            {
                                Debug.LogWarning($"程序集{hlModels[i].assemblyName}中未包含: {hlItems[j].componentName}，无法设置组件颜色高亮");
                                continue;
                            }
                            iconInfoList.Add(new IconInfoModel(type, hlItems[j].color));
                        }
                    }
                }
            }
        }
    }

    //区域颜色列表更新
    private static void UpdateAreaColorList()
    {
        //areaColorStack.Clear();
        subColorDic.Clear();

        foreach (KeyValuePair<string, Color> kv in areaColorDic)
        {
            GameObject targetPar = GameObject.Find(kv.Key);
            if (targetPar != null)
            {
                AddAreaColorChilds(targetPar, kv.Value);
            }
        }
    }

    private static void AddAreaColorChilds(GameObject targetPar, Color color)
    {
        subColorDic.Add(targetPar.GetInstanceID(), color);

        int childCount = targetPar.transform.childCount;
        if (childCount != 0)
        {
            for (int i = 0; i < childCount; i++)
            {
                AddAreaColorChilds(targetPar.transform.GetChild(i).gameObject, color);
            }
        }
    }

    private static void HierarchyChanged()
    {
        if (!EnableCustomHierarchy) return;

        Stopwatch stopWatch = new Stopwatch();
        stopWatch.Start();

        hierarchyChanged = true;

        UpdateAreaColorList();

        stopWatch.Stop();
        long expendTime = stopWatch.ElapsedMilliseconds;
        if (expendTime > 10)
        {
            Debug.LogWarning($"Hierarchy Changed耗时较长: {stopWatch.ElapsedMilliseconds}ms");
        }
    }

    //绘制Hiercrchy
    private static void HierarchyWindowOnGUI(int instanceId, Rect selectionRect)
    {
        if (!EnableCustomHierarchy) return;

        Color fontColor = Color.white;
        try
        {
            GameObject go = (GameObject)EditorUtility.InstanceIDToObject(instanceId);
            if (null == go)
            {
                return;
            }

            int insID = go.GetInstanceID();
            float curHalfWidth = EditorGUIUtility.currentViewWidth / 2;

            //区域颜色显示
            GUI.backgroundColor = baseColor;
            if (EnableCustomHierarchyArea)
            {
                if (subColorDic.ContainsKey(insID))
                {
                    GUI.backgroundColor = subColorDic[insID];
                }
            }

            if (hierarchyChanged)
            {
                hierarchyChanged = false;
            }

            //图标排序
            int index = 0;

            //大于最小宽度时候的显示
            if (minShowWidth < curHalfWidth)
            {
                //Active勾选框
                bool activeToggle = GUI.Toggle(CreateRect(selectionRect, ref index), go.activeSelf, string.Empty);
                if (activeToggle != go.activeSelf)
                {
                    go.SetActive(activeToggle);
                }

                //静态对象标记
                if (go.isStatic)
                {
                    Rect rectIcon = CreateRect(selectionRect, ref index);
                    GUI.Label(rectIcon, "S");
                }
            }

            //绘制图标和颜色名称，小于最小图标绘制宽度时只改变名称颜色
            if (curHalfWidth > minIconShowWidth)
            {
                foreach (IconInfoModel model in iconInfoList)
                {
                    if (Draw(model.type, selectionRect, go, ref index))
                    {
                        if (model.changeColor)
                        {
                            fontColor = model.color;
                        }
                    }
                }
            }
            else
            {
                foreach (IconInfoModel model in iconInfoList)
                {
                    if (HasComponent(go, model.type, false))
                    {
                        if (model.changeColor)
                        {
                            fontColor = model.color;
                        }
                    }
                }
            }

            //InstanceID显示
            //if (curHalfWidth > insIDRightMargin)
            //{
            //    Rect insIDRect = new Rect(selectionRect);
            //    insIDRect.x += insIDRect.width - insIDRightMargin;
            //    insIDRect.width = insIDRightMargin;
            //    index++;
            //    Color origin = insIDStyle.normal.textColor;
            //    insIDStyle.normal.textColor = GUI.backgroundColor;
            //    GUI.Label(insIDRect, insID.ToString(), insIDStyle);
            //    insIDStyle.normal.textColor = origin;
            //}

            Rect targetRect = selectionRect;
            targetRect.x += colorFontOffsetX;
            targetRect.y += colorFontOffsetY;

            if (EnableCustomHierarchyColor && fontColor != Color.white && go.activeInHierarchy)
            {
                Color originColor = colorLabelStyle.normal.textColor;
                colorLabelStyle.normal.textColor = fontColor;
                GUI.Label(targetRect, go.name, colorLabelStyle);
                colorLabelStyle.normal.textColor = originColor;
            }
            else if (EnableCustomHierarchyAreaName && subColorDic.ContainsKey(insID) && go.activeInHierarchy)
            {
                Color originColor = colorLabelStyle.normal.textColor;
                colorLabelStyle.normal.textColor = subColorDic[insID];
                GUI.Label(targetRect, go.name, colorLabelStyle);
                colorLabelStyle.normal.textColor = originColor;
            }
        }
        catch (Exception e)
        {
            // Debug.LogError(e.Message + "\n" + PrefabPreviewUtil.HighlightStackTrace(e.StackTrace));
        }
    }

    //组件名字高亮，图标
    private struct IconInfoModel
    {
        public IconInfoModel(Type type) : this(type, Color.white, false) { }

        public IconInfoModel(Type type, Color color) : this(type, color, true) { }

        private IconInfoModel(Type type, Color color, bool changeColor)
        {
            this.type = type;
            this.color = color;
            this.changeColor = changeColor;
        }

        public Type type;
        public bool changeColor;
        public Color color;
    }

    private static void SubColorDicAdd(Dictionary<int, Color> dic, Transform parTrans, Color color)
    {
        for (int i = 0; i < parTrans.childCount; i++)
        {
            Transform child = parTrans.GetChild(i);
            int insID = child.gameObject.GetInstanceID();
            if (!dic.ContainsKey(insID))
            {
                dic.Add(insID, color);
            }
            for (int j = 0; j < child.childCount; j++)
            {
                SubColorDicAdd(dic, child, color);
            }
        }
    }

    /// <summary>
    /// 检测是否含有组件
    /// </summary>
    /// <typeparam name="T">检查类型</typeparam>
    /// <param name="checkChildren">是否检测子层级</param>
    /// <returns>是否含有期望组件</returns>
    public static bool HasComponent<T>(GameObject go, bool checkChildren) where T : Component
    {
        if (!checkChildren)
        {
            return go.GetComponent<T>();
        }
        else
        {
            return go.GetComponentsInChildren<T>().FirstOrDefault() != null;
        }
    }

    /// <summary>
    /// 检测是否含有组件
    /// </summary>
    /// <typeparam name="T">检查类型</typeparam>
    /// <param name="checkChildren">是否检测子层级</param>
    /// <returns>是否含有期望组件</returns>
    public static bool HasComponent(GameObject go, Type type, bool checkChildren)
    {
        if (!checkChildren)
        {
            return go.GetComponent(type) != null;
        }
        else
        {
            return go.GetComponentsInChildren(type).FirstOrDefault() != null;
        }
    }

    /// <summary>
    /// 判断父物体中是否有目标名称的物体
    /// </summary>
    /// <param name="targetName">目标父物体名称</param>
    public static bool ExistParent(Transform trans, string targetName)
    {
        if (trans == null)
        {
            return false;
        }
        if (trans.gameObject.name.Equals(targetName))
        {
            return true;
        }
        return ExistParent(trans.parent, targetName);
    }

    #region Properties
    //是否开启自定义Hierarchy视图
    private const string CustomHierarchyKey = "EnableCustomHierarchy";
    private static int enableCustomHierarchy = -1;
    internal static bool EnableCustomHierarchy
    {
        get
        {
            if (enableCustomHierarchy == -1)
            {
                enableCustomHierarchy = EditorPrefs.GetInt(CustomHierarchyKey, 0);
            }
            return enableCustomHierarchy == 1;
        }
        set
        {
            int newValue = value ? 1 : 0;
            if (newValue != enableCustomHierarchy)
            {
                enableCustomHierarchy = newValue;
                EditorPrefs.SetInt(CustomHierarchyKey, enableCustomHierarchy);
            }
        }
    }
    //是否开启自定义Hierarchy颜色高亮
    private const string CustomHierarchyColorKey = "EnableCustomHierarchyColor";
    private static int enableCustomHierarchyColor = -1;
    internal static bool EnableCustomHierarchyColor
    {
        get
        {
            if (enableCustomHierarchyColor == -1)
            {
                enableCustomHierarchyColor = EditorPrefs.GetInt(CustomHierarchyColorKey, 1);
            }
            return enableCustomHierarchyColor == 1;
        }
        set
        {
            int newValue = value ? 1 : 0;
            if (newValue != enableCustomHierarchyColor)
            {
                enableCustomHierarchyColor = newValue;
                EditorPrefs.SetInt(CustomHierarchyColorKey, enableCustomHierarchyColor);
            }
        }
    }
    //是否开启自定义Hierarchy颜色区块
    private const string CustomHierarchyAreaKey = "EnableCustomHierarchyArea";
    private static int enableCustomHierarchyArea = -1;
    internal static bool EnableCustomHierarchyArea
    {
        get
        {
            if (enableCustomHierarchyArea == -1)
            {
                enableCustomHierarchyArea = EditorPrefs.GetInt(CustomHierarchyAreaKey, 1);
            }
            return enableCustomHierarchyArea == 1;
        }
        set
        {
            int newValue = value ? 1 : 0;
            if (newValue != enableCustomHierarchyArea)
            {
                enableCustomHierarchyArea = newValue;
                EditorPrefs.SetInt(CustomHierarchyAreaKey, enableCustomHierarchyArea);
            }
        }
    }
    //是否开启自定义颜色区块名称高亮
    private const string CustomHierarchyAreaNameKey = "EnableCustomHierarchyAreaName";
    private static int enableCustomHierarchyAreaName = -1;
    internal static bool EnableCustomHierarchyAreaName
    {
        get
        {
            if (enableCustomHierarchyAreaName == -1)
            {
                enableCustomHierarchyAreaName = EditorPrefs.GetInt(CustomHierarchyAreaNameKey, 0);
            }
            return enableCustomHierarchyAreaName == 1;
        }
        set
        {
            int newValue = value ? 1 : 0;
            if (newValue != enableCustomHierarchyAreaName)
            {
                enableCustomHierarchyAreaName = newValue;
                EditorPrefs.SetInt(CustomHierarchyAreaNameKey, enableCustomHierarchyAreaName);
            }
        }
    }
    #endregion
}

/// <summary>
/// 自定义Hierarchy开关
/// </summary>
public class EnableCustomHierarchy : EditorWindow
{
    private const string ToggleTitle = "Tools/Hierarchy自定义/开启Hierarchy自定义";
    private const string ColorToggleTitle = "Tools/Hierarchy自定义/开启Hierarchy组件颜色高亮";
    private const string AreaToggleTitle = "Tools/Hierarchy自定义/开启Hierarchy颜色区块";
    private const string AreaNameToggleTitle = "Tools/Hierarchy自定义/开启Hierarchy颜色区块名称高亮";
    private const string InfoTitle = "Tools/Hierarchy自定义/说明";

    //自定义Hierarchy视图开关
    [MenuItem(ToggleTitle, false)]
    public static void IconToggle()
    {
        CustomHierarchy.EnableCustomHierarchy = !CustomHierarchy.EnableCustomHierarchy;
    }
    [MenuItem(ToggleTitle, true)]
    public static bool SetIconToggle()
    {
        Menu.SetChecked(ToggleTitle, CustomHierarchy.EnableCustomHierarchy);
        return true;
    }

    //自定义Hierarchy颜色高亮开关
    [MenuItem(ColorToggleTitle, false)]
    public static void ColorToggle()
    {
        CustomHierarchy.EnableCustomHierarchyColor = !CustomHierarchy.EnableCustomHierarchyColor;
    }
    [MenuItem(ColorToggleTitle, true)]
    public static bool SetColorToggle()
    {
        Menu.SetChecked(ColorToggleTitle, CustomHierarchy.EnableCustomHierarchyColor);
        return true;
    }

    //自定义Hierarchy颜色区块开关
    [MenuItem(AreaToggleTitle, false)]
    public static void AreaToggle()
    {
        CustomHierarchy.EnableCustomHierarchyArea = !CustomHierarchy.EnableCustomHierarchyArea;
    }
    [MenuItem(AreaToggleTitle, true)]
    public static bool SetAreaToggle()
    {
        Menu.SetChecked(AreaToggleTitle, CustomHierarchy.EnableCustomHierarchyArea);
        return true;
    }

    //自定义颜色区块名称高亮开关
    [MenuItem(AreaNameToggleTitle, false)]
    public static void AreaNameToggle()
    {
        CustomHierarchy.EnableCustomHierarchyAreaName = !CustomHierarchy.EnableCustomHierarchyAreaName;
    }
    [MenuItem(AreaNameToggleTitle, true)]
    public static bool SetAreaNameToggle()
    {
        Menu.SetChecked(AreaNameToggleTitle, CustomHierarchy.EnableCustomHierarchyAreaName);
        return true;
    }
    //说明面板
    [MenuItem(InfoTitle, false)]
    public static void InfoPanel()
    {
        GetWindow<CustomHierarchyInfo>("自定义Hierarchy说明");
    }
}

/// <summary>
/// 自定义Hierarchy说明面板
/// </summary>
class CustomHierarchyInfo : EditorWindow
{
    private const string info = @"
  该工具可以在Hierarchy窗口显示物体上所带有的组件图标以及该物体是否为static\active等状态信息
  且可以根据物体所带有的组件或其名称来改变物体名称的颜色等

  >可通过快捷键<color=#E5E37F>Shift+M</color>开关Hierarchy窗口样式自定义
  如想显示更多信息可在CustomHierarchy.cs的HierarchyWindowOnGUI方法中添加

    
  >组件图标显示和组件颜色高亮可在<color=#E5E37F>Scripts/Game/Editor/UGUI/CustomHierarchyConfig.asset</color>中配置
  例如希望显示Canvas的图标并带有Canvas组件的物体名显示为黄色，则在Highlight Models下程序集为
  UnityEngine的Items中填入Canvas并设置对应颜色即可


  >颜色区块可以使某一名称的物体包括其子物体显示为某一颜色
  具体可以在<color=#E5E37F>Scripts/Game/Editor/UGUI/CustomHierarchyConfig.asset</color>中配置
  例如希望MainLayer及其子物体显示为黄色则在Models下填入MainLayer然后选中对应颜色即可
  物体名称的颜色变化优先级低于上面组件的颜色，名称高亮可在设置中关闭";

    private static GUIStyle style;

    private void Awake()
    {
        style = new GUIStyle("label");
        style.fontSize = 16;
        style.richText = true;
        minSize = new Vector2(45 * style.fontSize, 50);
    }

    private void OnGUI()
    {
        GUILayout.Label(info, style);
    }
}
