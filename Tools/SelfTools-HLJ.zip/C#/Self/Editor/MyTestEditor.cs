﻿using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MyTest))]
class MyTestEditor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        MyTest myTest = target as MyTest;

        if (GUILayout.Button("执行一次"))
        {
            myTest?.ExecuteOnce();
        }
    }
}