﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using BehaviorDesigner.Runtime;
using UnityEditor;
using UnityEngine;
using XLua;
using Debug = UnityEngine.Debug;

[ExecuteInEditMode]
public class MyTest : MonoBehaviour
{
    public bool executeUpdate = false;

    public void ExecuteOnce()
    {
    }

    public void ExecuteUpdate()
    {
    }

    private void Update()
    {
        if (executeUpdate)
        {
            ExecuteUpdate();
        }
    }

    private void Awake()
    {
        if (Application.isPlaying)
        {
            DontDestroyOnLoad(gameObject);
        }
    }
}