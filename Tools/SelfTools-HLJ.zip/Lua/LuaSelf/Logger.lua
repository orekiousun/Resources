local CSDebug = CS.UnityEngine.Debug

---@class Logger
local Logger = {}

---@class Logger.eLogLevel 日志开放等级
Logger.eLogLevel = {
    Off = 0,
    Debug = 1,
    Warning = 1 << 1,
    Error = 1 << 2,
}

---Log方法字典
local LoggerDic = {
    [Logger.eLogLevel.Debug] = CSDebug.Log,
    [Logger.eLogLevel.Warning] = CSDebug.LogWarning,
    [Logger.eLogLevel.Error] = CSDebug.LogError
}

---@param ... string | table
function Logger.Debug(...)
    Logger.DoLog(Logger.eLogLevel.Debug, ...)
end

---@param ... string | table
function Logger.Warning(...)
    Logger.DoLog(Logger.eLogLevel.Warning, ...)
end

---@param ... string | table
function Logger.Error(...)
    Logger.DoLog(Logger.eLogLevel.Error, ...)
end

---执行分级输出日志
---@private
---@param logLevel eLogLevel 日志等级
---@param ... string | table
function Logger.DoLog(logLevel, ...)
    if LoggerDic[logLevel] ~= nil then
        LoggerDic[logLevel](debug.traceback(Logger.CreateLogMsg(...)))
    end
end

---创建log消息
---@private
---@param ... string | table
---@return string
function Logger.CreateLogMsg(...)
    local args = table.pack(...)
    if args == nil or #args < 1 then
        LoggerDic[Logger.eLogLevel.Error]("Logger.CreateLogMsg: args is nil or length is zero!")
        return
    end
    local msg = Logger.ToString(table.remove(args, 1))
    local index = 1
    local fmtArg = {}
    if type(msg) == "string" then
        for _ in string.gmatch(msg, "%%s") do
            fmtArg[index] = Logger.ToString(args[index])
            index = index + 1
        end
        if index > 1 then
            msg = string.format(msg, table.unpack(fmtArg))
        end
        for i = index, #args do
            msg = msg .. "," .. Logger.ToString(args[i])
        end
    end
    return msg
end

---Lua表转字符串
---@param tab table
---@param desc string 描述
---@param maxDeep number 最大深度
function Logger.TabToString(tab, desc, maxDeep)
    if type(maxDeep) ~= "number" then
        maxDeep = 20
    end

    local result = {}
    local lookupTab = {}

    local function cc(v)
        if type(v) == "string" then
            v = '"' .. v .. '"'
        end
        return tostring(v)
    end

    local function _TabToString(_value, _desc, indent, deep, kenLen)
        _desc = _desc or "<var>"
        local spc = ""
        if type(kenLen) == "number" then
            spc = string.rep(" ", kenLen - string.len(cc(_desc)))
        end
        if type(_value) ~= "table" then
            result[#result + 1] = string.format("%s%s%s = %s,", indent, cc(_desc), spc, cc(_value))
        elseif lookupTab[_value] then
            result[#result + 1] = string.format("%s%s%s = *REF*", indent, _desc, spc)
        else
            lookupTab[_value] = true
            if deep > maxDeep then
                result[#result + 1] = string.format("%s%s = *MAX DEEP*", indent, _desc)
            else
                result[#result + 1] = string.format("%s%s = {", indent, cc(_desc))
                local indent_ = indent .. "    "
                local kenLen_ = 0
                local keys = {}
                local values = {}

                for k, v in pairs(_value) do
                    keys[#keys + 1] = k
                    local vk = cc(k)
                    local vk1 = string.len(vk)
                    if vk1 > kenLen_ then
                        kenLen_ = vk1
                    end

                    values[k] = v
                end

                table.sort(keys, function(a, b)
                    if type(a) == "number" and type(b) == "number" then
                        return a < b
                    else
                        return tostring(a) < tostring(b)
                    end
                end)

                for _, k in pairs(keys) do
                    local tempValue = values[k]
                    if k == "loc" and type(tempValue) == "string" and #tempValue == 13 then
                        tempValue = "位置bytes"
                    end
                    _TabToString(tempValue, k, indent_, deep + 1, kenLen_)
                end

                result[#result + 1] = string.format("%s},", indent)
            end
        end
    end

    _TabToString(tab, desc, "", 1)
    return table.concat(result, "\n")
end

---转换为string
---@param value any
---@return string
function Logger.ToString(value)
    if value == nil then
        return "nil"
    end
    local valueType = type(value)
    if valueType == "table" then
        value = Logger.TabToString(value, "\n")
    elseif valueType == "boolean" or valueType == "number" or valueType == "userdata" or valueType == "function" then
        value = tostring(value)
    end
    return value
end

---@type Logger
_G.Logger = Logger
---@return Logger
return Logger
