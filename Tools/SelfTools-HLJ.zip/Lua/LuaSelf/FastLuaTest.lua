-----------------------------------------------------------------------
-- 点击运行按钮右侧的'Lua'按钮执行'Execute'测试方法，可在运行时修改该脚本
-----------------------------------------------------------------------

--region ------------- Header -------------

local Launcher = require("Launcher")
local LuaEditorApi = require("LuaEditorApi")
local Logger = require("Logger")

local Log = Logger and Logger.Error or _print_e

---@class FastLuaTest
local FastLuaTest = {}

--endregion ------------- Header -------------

---执行
function FastLuaTest.Execute1()
    Log(GL.Model.ModelOldPlayerBack.comebackEx.keepSign)
end

---执行2
function FastLuaTest.Execute2()
end

---执行3
function FastLuaTest.Execute3()
    local view = GL.SM.SceneModelUtil.CreateView()
    local player = view:CreateObj(GL.SM.SceneModelDef.ObjType.Player)
    local ball = view:CreateObj(GL.SM.SceneModelDef.ObjType.Ball)
    local ball2 = view:CreateObj(GL.SM.SceneModelDef.ObjType.Ball)
    local scene = view:CreateObj(GL.SM.SceneModelDef.ObjType.Scene)
    local camera = view:CreateObj(GL.SM.SceneModelDef.ObjType.Camera)
    local timeline = view:CreateObj(GL.SM.SceneModelDef.ObjType.Timeline)

    camera:SetDepth(5)
    camera:SetLocalPosition(-0.9, 7.1, 8.9)
    camera:SetLocalEulerAngle(12.326, 179.006, -0.893)
    camera:AddBloom()
    camera:SetVisible(false)

    --player:SetLocalPosition(-3.77, 0, -10.72)
    --player:SetLocalEulerAngle(0, 89.604, 0)

    local playerID = 96011401
    local parallel = {
        function(finishCall)
            player:LoadPlayer(playerID, finishCall)
        end,
        function(finishCall)
            ball:LoadAsset("ball_skin01", finishCall)
        end,
        function(finishCall)
            ball2:LoadAsset("ball_skin01", finishCall)
        end,
        function(finishCall)
            scene:LoadScene(6038, finishCall)
        end,
        function(finishCall)
            timeline:LoadAsset("BasketballSkinTimelinePrefab", finishCall)
        end
    }
    GL.SM.SceneModelUtil.ParallelCall(parallel, function()
        player:AddComponentToAsset(CS.UnityEngine.Animator)
        player:CatchBall(ball)

        timeline:BindTrackObjByObjID("PlayerAnimation1", player)
        timeline:BindTrackObjByObjID("PlayerAnimation2", player)
        timeline:BindTrackObjByObjID("InnerBallActive", ball)
        timeline:BindTrackObjByObjID("OuterBallActive", ball2)
        timeline:BindTrackObjByObjID("OuterBallTrailActive", ball2, "balFbxRoot/balltrail")
        timeline:BindTrackObjByObjID("BallAnimation", ball2)
        timeline:BindTrackObjByObjID("BasketballNetAnimation", scene, "mode/base/base_l", true, CS.UnityEngine.Animator)
        timeline:SetTimelineWrapMode(GL.SM.SceneModelDef.TimelineWrapMode.Loop)
        timeline:PlayTimeline()

        camera:SetVisible(true)
    end)
end

--region ------------- Inner -------------

---@private
function FastLuaTest.Dispatch(eventName, param)
    GL.File.LuaEvent.Dispatch(eventName, param)
end

---@private
function FastLuaTest.PushWindow(wndName)
    local wndCls = GL.UI.WindowClass.CreateParam()
    wndCls.wndName = wndName
    GL.UI.UIStack.PushWindow(wndCls)
end

---重载
function FastLuaTest.Reload()
    package.loaded = {}
    package.preload = {}
    require("Launcher")
    --local list = {
    --    "PotentialRecommendWindow"
    --}
    --for _, v in ipairs(list) do
    --    package.loaded[v] = nil
    --    package.preload[v] = nil
    --    _print_e(string.format("已重载  <color=aqua>%s</color>", v))
    --end
end

--[[

    local sw = CS.System.Diagnostics.Stopwatch()
    sw:Start()
    Log(sw.ElapsedMilliseconds)

--]]

--endregion ------------- Inner -------------

---@return FastLuaTest
return FastLuaTest