---@class SelfLuaEditorApi
local SelfLuaEditorApi = {}

---移除模块缓存
---@param moduleName string 模块名
function SelfLuaEditorApi.RemoveModule(moduleName)
    package.loaded[moduleName] = nil
    package.preload[moduleName] = nil
end

---@return SelfLuaEditorApi
return SelfLuaEditorApi
